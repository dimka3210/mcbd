#! /bin/sh
java Main